#' isbn_sample
#'
#' Description.
#'
#' @format A data frame with  rows and  variables:
#' \describe{
#' }
#' @source Source
"isbn_sample"
